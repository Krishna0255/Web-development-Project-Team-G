function read1(){
    var dots = document.getElementById("dots1");
    var moretext = document.getElementById("more1");
    var btntext= document.getElementById("mybtn1");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read2(){
    var dots = document.getElementById("dots2");
    var moretext = document.getElementById("more2");
    var btntext= document.getElementById("mybtn2");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read3(){
    var dots = document.getElementById("dots3");
    var moretext = document.getElementById("more3");
    var btntext= document.getElementById("mybtn3");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read4(){
    var dots = document.getElementById("dots4");
    var moretext = document.getElementById("more4");
    var btntext= document.getElementById("mybtn4");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read5(){
    var dots = document.getElementById("dots5");
    var moretext = document.getElementById("more5");
    var btntext= document.getElementById("mybtn5");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read6(){
    var dots = document.getElementById("dots6");
    var moretext = document.getElementById("more6");
    var btntext= document.getElementById("mybtn6");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read7(){
    var dots = document.getElementById("dots7");
    var moretext = document.getElementById("more7");
    var btntext= document.getElementById("mybtn7");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}

function read8(){
    var dots = document.getElementById("dots8");
    var moretext = document.getElementById("more8");
    var btntext= document.getElementById("mybtn8");

    if (dots.style.display === "none"){
        dots.style.display = "inline";
        btntext.innerHTML = "Read More";
        moretext.style.display = "none";
    }
    else{
        dots.style.display = "none";
        btntext.innerHTML = "Read Less";
        moretext.style.display = "inline"; 
    }
}




